import 'dart:io';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:printing/printing.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

void main() => runApp(MaterialApp(home: GnaBarkodSistemi()));

class GnaBarkodSistemi extends StatefulWidget {
  @override
  _GnaBarkodSistemiState createState() => _GnaBarkodSistemiState();
}

class _GnaBarkodSistemiState extends State<GnaBarkodSistemi> {
  String barkodNo = "";
  String urunAdi = "";
  String fiyat = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("G.N.A Wear Kamera")),
      body: Column(
        children: [
          Expanded(
            flex: 2,
            child: MobileScanner(
              onDetect: (capture) {
                final List<Barcode> barcodes = capture.barcodes;
                setState(() {
                  barkodNo = barcodes.isNotEmpty ? barcodes.first.rawValue ?? "" : "";
                });
              },
            ),
          ),
          Expanded(
            flex: 1,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(10),
              child: Column(
                children: [
                  Text("Okunan Barkod: $barkodNo",
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  TextField(
                    decoration: const InputDecoration(labelText: "Ürün Adı"),
                    onChanged: (v) => urunAdi = v,
                  ),
                  TextField(
                    decoration: const InputDecoration(labelText: "Fiyat"),
                    onChanged: (v) => fiyat = v,
                  ),
                  ElevatedButton(
                    onPressed: _yazdir,
                    child: const Text("Yazdır"),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _yazdir() async {
    final doc = pw.Document();
    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat(50 * PdfPageFormat.mm, 30 * PdfPageFormat.mm),
        build: (pw.Context context) => pw.Center(
          child: pw.Column(
            children: [
              pw.Text("G.N.A WEAR"),
              pw.Text(urunAdi),
              pw.BarcodeWidget(
                barcode: pw.Barcode.code128(),
                data: barkodNo,
                width: 80,
                height: 30,
              ),
              pw.Text("$fiyat TL"),
            ],
          ),
        ),
      ),
    );
    await Printing.layoutPdf(onLayout: (format) async => doc.save());
  }
}

    
    
                  
      




  
                      
  
            

        
                     
                          
              
                         
