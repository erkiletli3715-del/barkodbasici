package com.example.barkodbasici

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
